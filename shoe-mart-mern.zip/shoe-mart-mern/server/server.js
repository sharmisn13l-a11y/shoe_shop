require('dotenv').config();
const path = require('path'), fs = require('fs');
const express = require('express'), mongoose = require('mongoose'), cors = require('cors'), jwt = require('jsonwebtoken');
const { MONGO_URI, ADMIN_PIN = '1234', JWT_SECRET = 'change-me', PORT = 5000 } = process.env;

const app = express();
app.use(cors());
app.use(express.json({ limit: '5mb' }));

/* ---------- Models ---------- */
const Product = mongoose.model('Product', new mongoose.Schema({
  name: { type: String, required: true }, person: String, type: String, use: String,
  cost: { type: Number, default: 0 }, sell: { type: Number, required: true },
  sizes: { type: Map, of: Number }, img: String
}, { timestamps: true }));

const Sale = mongoose.model('Sale', new mongoose.Schema({
  no: String, customer: String, phone: String,
  items: [{ name: String, size: String, qty: Number, sell: Number, cost: Number }],
  disc: Number, total: Number, mode: String, profit: Number
}, { timestamps: true }));

const Setting = mongoose.model('Setting', new mongoose.Schema({
  key: { type: String, unique: true }, name: String, wa: String, upi: String, adr: String
}));

/* ---------- Helpers ---------- */
const isAdmin = req => { try { jwt.verify((req.headers.authorization || '').slice(7), JWT_SECRET); return true; } catch { return false; } };
const need = (req, res, next) => isAdmin(req) ? next() : res.status(401).json({ error: 'Please log in as owner' });
const h = fn => (req, res) => fn(req, res).catch(e => res.status(400).json({ error: e.message }));
const clean = b => ({ name: b.name, person: b.person, type: b.type, use: b.use, cost: +b.cost || 0, sell: +b.sell, sizes: b.sizes, img: b.img });

/* ---------- Auth ---------- */
app.post('/api/login', (req, res) =>
  req.body.pin === ADMIN_PIN
    ? res.json({ token: jwt.sign({ a: 1 }, JWT_SECRET, { expiresIn: '12h' }) })
    : res.status(401).json({ error: 'Wrong PIN. Try again.' }));

/* ---------- Products (buying price is hidden from the public) ---------- */
app.get('/api/products', h(async (req, res) => {
  const a = isAdmin(req);
  const list = await Product.find().sort('-createdAt').lean();
  res.json(list.map(p => { p.id = String(p._id); if (!a) delete p.cost; return p; }));
}));
app.post('/api/products', need, h(async (req, res) => res.json(await Product.create(clean(req.body)))));
app.put('/api/products/:id', need, h(async (req, res) => res.json(await Product.findByIdAndUpdate(req.params.id, clean(req.body), { new: true }))));
app.delete('/api/products/:id', need, h(async (req, res) => { await Product.findByIdAndDelete(req.params.id); res.json({ ok: true }); }));

/* ---------- Shop settings ---------- */
const getSet = async () => (await Setting.findOne({ key: 'shop' }).lean()) || { name: 'Singapoore Shoe Mart', wa: '', upi: '', adr: '' };
app.get('/api/settings', h(async (req, res) => { const s = await getSet(); if (!isAdmin(req)) delete s.upi; res.json(s); }));
app.put('/api/settings', need, h(async (req, res) => {
  const { name, wa, upi, adr } = req.body;
  res.json(await Setting.findOneAndUpdate({ key: 'shop' }, { name, wa, upi, adr }, { upsert: true, new: true, lean: true }));
}));

/* ---------- Sales: stock is checked and deducted on the server ---------- */
app.post('/api/sales', need, h(async (req, res) => {
  const { items, disc = 0, mode, customer, phone } = req.body;
  if (!items || !items.length) throw new Error('No items in the bill');
  const lines = [];
  for (const it of items) {
    const p = await Product.findById(it.id);
    if (!p) throw new Error('Product not found');
    const have = p.sizes.get(it.size) || 0;
    if (have < it.qty) throw new Error(`${p.name} ${it.size}: only ${have} left`);
    lines.push({ p, it });
  }
  let sub = 0, cost = 0; const rows = [];
  for (const { p, it } of lines) {
    await Product.updateOne({ _id: p._id }, { $inc: { ['sizes.' + it.size]: -it.qty } });
    sub += p.sell * it.qty; cost += p.cost * it.qty;
    rows.push({ name: p.name, size: it.size, qty: it.qty, sell: p.sell, cost: p.cost });
  }
  const d = Math.min(+disc || 0, sub), total = sub - d;
  const no = 'B' + String((await Sale.countDocuments()) + 1).padStart(4, '0');
  res.json(await Sale.create({ no, customer, phone, items: rows, disc: d, total, mode, profit: total - cost }));
}));

app.get('/api/sales', need, h(async (req, res) => {
  const y = +req.query.year || new Date().getFullYear();
  res.json(await Sale.find({ createdAt: { $gte: new Date(y, 0, 1), $lt: new Date(y + 1, 0, 1) } }).sort('-createdAt').lean());
}));

/* ---------- Serve the React build in production ---------- */
const dist = path.join(__dirname, '../client/dist');
if (fs.existsSync(dist)) {
  app.use(express.static(dist));
  app.get('*', (req, res) => res.sendFile(path.join(dist, 'index.html')));
}

mongoose.connect(MONGO_URI)
  .then(() => app.listen(PORT, () => console.log('Shoe Mart running on port ' + PORT)))
  .catch(e => console.error('MongoDB connection failed:', e.message));

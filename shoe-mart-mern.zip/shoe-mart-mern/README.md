# Singapoore Shoe Mart — MERN app

MongoDB + Express + React (Vite) + Node. One server serves both the API and the website.

## 1. Get a free database
Create a free cluster on MongoDB Atlas, add a database user, allow network access (0.0.0.0/0), copy the connection string.

## 2. Run on your computer
```
cd server
cp .env.example .env      # open .env and paste your MONGO_URI, set ADMIN_PIN
npm install
npm run dev               # API on http://localhost:5000

# in a second terminal
cd client
npm install
npm run dev               # website on http://localhost:5173
```

## 3. Put it online (free)
Use Render.com (Web Service) with the repo root:
- Build command: `cd client && npm install && npm run build && cd ../server && npm install`
- Start command: `cd server && npm start`
- Environment variables: MONGO_URI, ADMIN_PIN, JWT_SECRET

The server automatically serves the built website, so customers and the owner use the same link.
Note: free Render services sleep when idle, so the first visit can take about 30 seconds.

## Owner login
Tap "Owner login" and enter the ADMIN_PIN from your .env file. Then open Settings and add your WhatsApp number and UPI ID.

import { useEffect, useState } from 'react';
import { QRCodeSVG } from 'qrcode.react';

const PERSON = ['Boys', 'Girls', 'Children', 'Seniors'];
const TYPE = ['Slippers', 'Shoes', 'Travel Bags'];
const USE = ['Normal / Daily', 'Professional / Formal'];
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

const API = import.meta.env.VITE_API_URL || '/api';
let token = localStorage.getItem('t') || '';
async function api(path, opts = {}) {
  const r = await fetch(API + path, {
    method: opts.method || 'GET',
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) },
    body: opts.body ? JSON.stringify(opts.body) : undefined
  });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(d.error || 'Request failed');
  return d;
}

const inr = n => '₹' + Math.round((n || 0) * 100) / 100;
const totalStock = p => Object.values(p.sizes || {}).reduce((a, b) => a + b, 0);
const parseSizes = t => { const o = {}; t.split(',').forEach(x => { const [s, n] = x.split(':'); if (s && s.trim()) o[s.trim()] = Math.max(0, parseInt(n) || 0); }); return o; };
const sizesText = s => Object.entries(s || {}).map(([k, v]) => k + ':' + v).join(', ');
const waLink = (num, text) => `https://wa.me/${String(num).replace(/\D/g, '')}?text=${encodeURIComponent(text)}`;
const download = (name, text) => { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([text], { type: 'text/csv' })); a.download = name; a.click(); };
const csv = rows => rows.map(r => r.map(v => `"${String(v ?? '').replace(/"/g, '""')}"`).join(',')).join('\n');
function resize(file) {
  return new Promise(res => {
    const r = new FileReader();
    r.onload = () => { const im = new Image(); im.onload = () => {
      const k = Math.min(1, 480 / Math.max(im.width, im.height)), c = document.createElement('canvas');
      c.width = im.width * k; c.height = im.height * k; c.getContext('2d').drawImage(im, 0, 0, c.width, c.height);
      res(c.toDataURL('image/jpeg', 0.72)); }; im.src = r.result; };
    r.readAsDataURL(file);
  });
}

function Chips({ label, list, val, on }) {
  return (<>
    <p className="fl">{label}</p>
    <div className="chips">{['All', ...list].map(v => <button key={v} className={'chip' + (v === val ? ' on' : '')} onClick={() => on(v)}>{v}</button>)}</div>
  </>);
}

/* ================= CUSTOMER SHOP ================= */
function Shop({ set, say }) {
  const [ps, setPs] = useState(null);
  const [f, setF] = useState({ person: 'All', type: 'All', use: 'All', size: 'All' });
  const [q, setQ] = useState('');
  const [sel, setSel] = useState(null);
  useEffect(() => { api('/products').then(setPs).catch(e => say(e.message)); }, []);
  if (!ps) return <div className="empty">Loading products…</div>;

  const sizes = [...new Set(ps.flatMap(p => Object.entries(p.sizes || {}).filter(([, n]) => n > 0).map(([s]) => s)))]
    .sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));
  const list = ps.filter(p => (f.person === 'All' || p.person === f.person) && (f.type === 'All' || p.type === f.type) &&
    (f.use === 'All' || p.use === f.use) && (f.size === 'All' || (p.sizes?.[f.size] || 0) > 0) &&
    (!q || p.name.toLowerCase().includes(q.toLowerCase())));
  const set1 = k => v => setF({ ...f, [k]: v });
  const clear = () => { setF({ person: 'All', type: 'All', use: 'All', size: 'All' }); setQ(''); };
  const active = Object.values(f).some(v => v !== 'All') || q;

  return (<>
    <input placeholder="Search slippers, shoes, bags…" value={q} onChange={e => setQ(e.target.value)} aria-label="Search" />
    <Chips label="Who is it for" list={PERSON} val={f.person} on={set1('person')} />
    <Chips label="Product type" list={TYPE} val={f.type} on={set1('type')} />
    <Chips label="Usage" list={USE} val={f.use} on={set1('use')} />
    <Chips label="Size (only sizes in stock)" list={sizes} val={f.size} on={set1('size')} />
    <div className="count">{list.length} product{list.length !== 1 && 's'} found {active && <button className="chip" onClick={clear}>Clear filters</button>}</div>
    {!list.length
      ? <div className="empty">{ps.length ? 'Nothing matches these filters.' : 'No products yet.'}</div>
      : <div className="grid">{list.map(p => {
          const n = totalStock(p);
          return (
            <div className="card" key={p.id} onClick={() => setSel(p)}>
              <div className="ph" style={p.img ? { backgroundImage: `url(${p.img})` } : {}}>{!p.img && 'No photo'}</div>
              <div className="b">
                <h3>{p.name}</h3>
                <div className="tag">{p.person} · {p.type}</div>
                <div className="price">{inr(p.sell)}</div>
                <div><span className={'badge ' + (n > 0 ? 'in' : 'out')}>{n > 0 ? 'In stock' : 'Out of stock'}</span></div>
              </div>
            </div>);
        })}</div>}
    {sel && <div className="modal" onClick={() => setSel(null)}><div onClick={e => e.stopPropagation()}>
      <div className="ph" style={{ borderRadius: 10, ...(sel.img ? { backgroundImage: `url(${sel.img})` } : {}) }}>{!sel.img && 'No photo'}</div>
      <h2 style={{ margin: '10px 0 2px' }}>{sel.name}</h2>
      <div className="tag">{sel.person} · {sel.type} · {sel.use}</div>
      <div className="price" style={{ fontSize: 24 }}>{inr(sel.sell)}</div>
      <p className="fl">Sizes</p>
      <div className="sz" style={{ gap: 6 }}>{Object.entries(sel.sizes || {}).map(([s, n]) =>
        <span key={s} className={n > 0 ? '' : 'x'} style={{ fontSize: 14, padding: '3px 9px' }}>{s}{n > 0 && n <= 2 ? ` · only ${n} left` : ''}</span>)}</div>
      <div style={{ display: 'grid', gap: 8, marginTop: 14 }}>
        {set.wa && <a className="btn g" target="_blank" rel="noopener" href={waLink(set.wa, `Hi, I want to check "${sel.name}" (${inr(sel.sell)}). Is it available?`)}>Ask on WhatsApp</a>}
        <button className="btn l" onClick={() => setSel(null)}>Close</button>
      </div>
    </div></div>}
  </>);
}

/* ================= OWNER: BILLING ================= */
function Receipt({ set, bill }) {
  const s = bill.sale;
  return (<div className="rc">
    <div style={{ textAlign: 'center' }}><b>{set.name}</b><br />{set.adr}</div><hr />
    {s ? <>Bill {s.no}<br /></> : null}{new Date(s ? s.createdAt : Date.now()).toLocaleString('en-IN')}
    {bill.customer && <><br />Customer: {bill.customer}</>}<hr />
    {bill.items.map((i, k) => <div key={k}><div>{i.name} ({i.size})</div><div className="t"><span>{i.qty} x {i.sell}</span><span>{inr(i.qty * i.sell)}</span></div></div>)}<hr />
    {bill.disc > 0 && <div className="t"><span>Discount</span><span>-{inr(bill.disc)}</span></div>}
    <div className="t"><b>TOTAL</b><b>{inr(bill.total)}</b></div><div>Paid by: {bill.mode}</div><hr />
    <div style={{ textAlign: 'center' }}>Thank you. Visit again.</div>
  </div>);
}

function Billing({ set, say, ps, reload }) {
  const [pid, setPid] = useState(''); const [size, setSize] = useState(''); const [qty, setQty] = useState(1);
  const [cart, setCart] = useState([]); const [cu, setCu] = useState({ customer: '', phone: '' });
  const [disc, setDisc] = useState(0); const [mode, setMode] = useState('UPI'); const [bill, setBill] = useState(null);
  const p = ps.find(x => x.id === pid);
  const avail = Object.entries(p?.sizes || {}).filter(([, n]) => n > 0);
  const sub = cart.reduce((a, c) => a + c.qty * c.sell, 0);
  const d = Math.min(Math.max(+disc || 0, 0), sub), total = sub - d;

  const add = () => {
    if (!p || !size) return say('Choose a product and a size in stock');
    const have = p.sizes[size] || 0;
    const used = cart.filter(c => c.id === p.id && c.size === size).reduce((a, c) => a + c.qty, 0);
    if (used + qty > have) return say(`Only ${have} in stock for this size`);
    setCart(cs => { const e = cs.find(c => c.id === p.id && c.size === size);
      return e ? cs.map(c => c === e ? { ...c, qty: c.qty + qty } : c) : [...cs, { id: p.id, name: p.name, size, qty, sell: p.sell }]; });
    setQty(1);
  };
  const generate = () => { if (!cart.length) return say('Add at least one item'); setBill({ items: cart, total, disc: d, mode, customer: cu.customer, sale: null }); };
  const save = async () => {
    try {
      const sale = await api('/sales', { method: 'POST', body: { items: cart.map(c => ({ id: c.id, size: c.size, qty: c.qty })), disc: d, mode, ...cu } });
      setBill(b => ({ ...b, sale })); setCart([]); setCu({ customer: '', phone: '' }); setDisc(0); reload(); say('Bill saved. Stock updated.');
    } catch (e) { say(e.message); }
  };
  const closeBill = () => setBill(null);
  const sendWa = () => {
    const ph = bill.sale?.phone || cu.phone || prompt('Customer WhatsApp number (with country code, e.g. 919876543210)');
    if (!ph) return;
    const text = `*${set.name}*\n${bill.sale ? 'Bill ' + bill.sale.no + '\n' : ''}` + bill.items.map(i => `${i.name} (${i.size}) x${i.qty} = ${inr(i.qty * i.sell)}`).join('\n') + `\n*Total: ${inr(bill.total)}*\nThank you!`;
    window.open(waLink(ph.length === 10 ? '91' + ph : ph, text), '_blank');
  };

  return (<>
    <div className="panel"><h2>Counter billing</h2>
      <div className="row">
        <div><label>Product</label><select value={pid} onChange={e => { setPid(e.target.value); setSize(''); }}><option value="">Choose product</option>{ps.map(x => <option key={x.id} value={x.id}>{x.name} — {inr(x.sell)}</option>)}</select></div>
        <div><label>Size</label><select value={size} onChange={e => setSize(e.target.value)}><option value="">Choose size</option>{avail.map(([s, n]) => <option key={s} value={s}>{s} ({n} left)</option>)}</select></div>
      </div>
      <div className="row">
        <div><label>Quantity</label><input type="number" min="1" value={qty} onChange={e => setQty(Math.max(1, parseInt(e.target.value) || 1))} /></div>
        <div><label>&nbsp;</label><button className="btn" style={{ width: '100%' }} onClick={add}>Add to bill</button></div>
      </div>
    </div>
    <div className="panel"><h2>Current bill</h2>
      <div className="tw"><table>{cart.length
        ? <><thead><tr><th>Item</th><th>Size</th><th>Qty</th><th>Amount</th><th></th></tr></thead><tbody>{cart.map((c, i) =>
            <tr key={i}><td>{c.name}</td><td>{c.size}</td><td>{c.qty}</td><td>{inr(c.qty * c.sell)}</td><td><button className="btn r s" onClick={() => setCart(cart.filter((_, k) => k !== i))}>Remove</button></td></tr>)}</tbody></>
        : <tbody><tr><td className="empty">No items added yet.</td></tr></tbody>}</table></div>
      <div className="row">
        <div><label>Customer name (optional)</label><input value={cu.customer} onChange={e => setCu({ ...cu, customer: e.target.value })} /></div>
        <div><label>Phone (optional)</label><input inputMode="tel" value={cu.phone} onChange={e => setCu({ ...cu, phone: e.target.value })} /></div>
      </div>
      <div className="row">
        <div><label>Discount ₹</label><input type="number" min="0" value={disc} onChange={e => setDisc(e.target.value)} /></div>
        <div><label>Payment</label><select value={mode} onChange={e => setMode(e.target.value)}><option>UPI</option><option>Cash</option></select></div>
      </div>
      <p className="price" style={{ fontSize: 22 }}>Total {inr(total)}</p>
      <button className="btn g" style={{ width: '100%' }} onClick={generate}>Generate bill</button>
    </div>
    {bill && <div className="modal"><div style={{ textAlign: 'center' }}>
      <h2>{bill.sale ? 'Bill saved' : 'Bill ready'}</h2>
      {bill.mode === 'UPI' && !bill.sale && (set.upi
        ? <><p className="tag">Customer scans to pay</p><div className="qr"><QRCodeSVG size={220} value={`upi://pay?pa=${encodeURIComponent(set.upi)}&pn=${encodeURIComponent(set.name)}&am=${bill.total.toFixed(2)}&cu=INR`} /></div><p className="price">Pay {inr(bill.total)}</p></>
        : <p className="tag">Add your UPI ID in Settings to show the QR code.</p>)}
      <div style={{ textAlign: 'left' }}><Receipt set={set} bill={bill} /></div>
      <div style={{ display: 'grid', gap: 8 }}>
        {!bill.sale && <button className="btn g" onClick={save}>Payment received — save bill</button>}
        <button className="btn l" onClick={() => window.print()}>Print receipt</button>
        <button className="btn l" onClick={sendWa}>Send on WhatsApp</button>
        <button className="btn r" onClick={closeBill}>{bill.sale ? 'Start new bill' : 'Back'}</button>
      </div>
    </div></div>}
  </>);
}

/* ================= OWNER: PRODUCTS & STOCK ================= */
const BLANK = { name: '', person: PERSON[0], type: TYPE[0], use: USE[0], cost: '', sell: '', sizes: '', img: '' };
function Products({ say, ps, reload }) {
  const [f, setF] = useState(BLANK); const [id, setId] = useState('');
  const up = k => e => setF({ ...f, [k]: e.target.value });
  const save = async () => {
    const sizes = parseSizes(f.sizes);
    if (!f.name.trim() || !f.sell || !Object.keys(sizes).length) return say('Enter name, selling price and sizes like UK 6:4');
    try {
      await api(id ? '/products/' + id : '/products', { method: id ? 'PUT' : 'POST', body: { ...f, sizes } });
      setF(BLANK); setId(''); reload(); say('Product saved');
    } catch (e) { say(e.message); }
  };
  const del = async p => { if (confirm('Delete this product?')) { await api('/products/' + p.id, { method: 'DELETE' }); reload(); } };
  const low = ps.flatMap(p => Object.entries(p.sizes || {}).filter(([, n]) => n <= 2).map(([s, n]) => ({ k: p.id + s, p, s, n })));

  return (<>
    <div className="panel"><h2>{id ? 'Edit product' : 'Add product'}</h2>
      <label>Name</label><input value={f.name} onChange={up('name')} />
      <div className="row">
        <div><label>For</label><select value={f.person} onChange={up('person')}>{PERSON.map(x => <option key={x}>{x}</option>)}</select></div>
        <div><label>Type</label><select value={f.type} onChange={up('type')}>{TYPE.map(x => <option key={x}>{x}</option>)}</select></div>
      </div>
      <div className="row">
        <div><label>Usage</label><select value={f.use} onChange={up('use')}>{USE.map(x => <option key={x}>{x}</option>)}</select></div>
        <div><label>Photo</label><input type="file" accept="image/*" onChange={async e => e.target.files[0] && setF({ ...f, img: await resize(e.target.files[0]) })} /></div>
      </div>
      {f.img && <div className="thumb" style={{ backgroundImage: `url(${f.img})`, marginTop: 8 }} />}
      <div className="row">
        <div><label>Buying price ₹ (private)</label><input type="number" min="0" value={f.cost} onChange={up('cost')} /></div>
        <div><label>Selling price ₹</label><input type="number" min="0" value={f.sell} onChange={up('sell')} /></div>
      </div>
      <label>Sizes and stock — size:quantity, comma separated</label>
      <input placeholder="UK 6:4, UK 7:6, UK 8:2" value={f.sizes} onChange={up('sizes')} />
      <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
        <button className="btn" onClick={save}>Save product</button>
        <button className="btn l" onClick={() => { setF(BLANK); setId(''); }}>Clear</button>
      </div>
    </div>
    <div className="panel"><h2>Low stock (2 or fewer)</h2>
      {low.length ? low.map(x => <div key={x.k} style={{ padding: '4px 0' }}>{x.p.name} — {x.s}: <span className={'badge ' + (x.n ? 'lowb' : 'out')}>{x.n ? x.n + ' left' : 'Out'}</span></div>) : <p className="tag">All sizes have enough stock.</p>}
    </div>
    <div className="panel"><h2>All products</h2><div className="tw"><table>
      {ps.length ? <><thead><tr><th></th><th>Product</th><th>Buy / Sell</th><th>Stock</th><th></th></tr></thead><tbody>{ps.map(p =>
        <tr key={p.id}><td><div className="thumb" style={p.img ? { backgroundImage: `url(${p.img})` } : {}} /></td>
          <td>{p.name}<div className="tag">{p.person} · {p.type}</div></td><td>{inr(p.cost)} / {inr(p.sell)}</td><td>{totalStock(p)}</td>
          <td style={{ whiteSpace: 'nowrap' }}><button className="btn l s" onClick={() => { setId(p.id); setF({ ...p, cost: p.cost, sizes: sizesText(p.sizes) }); scrollTo({ top: 0, behavior: 'smooth' }); }}>Edit</button> <button className="btn r s" onClick={() => del(p)}>Delete</button></td></tr>)}</tbody></>
        : <tbody><tr><td className="empty">No products yet. Add your first one above.</td></tr></tbody>}
    </table></div></div>
  </>);
}

/* ================= OWNER: REPORTS ================= */
const stat = l => ({ rev: l.reduce((a, s) => a + s.total, 0), pr: l.reduce((a, s) => a + s.profit, 0), upi: l.filter(s => s.mode === 'UPI').reduce((a, s) => a + s.total, 0), n: l.length });
function Stats({ l }) {
  const s = stat(l);
  return <div className="stats">{[['Turnover', inr(s.rev)], ['Net profit', inr(s.pr)], ['UPI', inr(s.upi)], ['Cash', inr(s.rev - s.upi)], ['Bills', s.n]].map(([n, v]) => <div className="stat" key={n}><b>{v}</b><span>{n}</span></div>)}</div>;
}
function Reports({ say }) {
  const now = new Date(), cy = now.getFullYear();
  const [y, setY] = useState(cy); const [sales, setSales] = useState([]);
  useEffect(() => { api('/sales?year=' + y).then(setSales).catch(e => say(e.message)); }, [y]);
  const dt = s => new Date(s.createdAt);
  const today = sales.filter(s => dt(s).toDateString() === now.toDateString());
  const month = sales.filter(s => y === cy && dt(s).getMonth() === now.getMonth());
  const m = MONTHS.map((_, i) => stat(sales.filter(s => dt(s).getMonth() === i)));
  const max = Math.max(1, ...m.map(x => x.rev));
  const best = {}; month.forEach(s => s.items.forEach(i => best[i.name] = (best[i.name] || 0) + i.qty));
  const top = Object.entries(best).sort((a, b) => b[1] - a[1]).slice(0, 5);
  const years = Array.from({ length: 6 }, (_, i) => cy - i);

  return (<>
    <div className="panel"><h2>Today</h2><Stats l={today} /></div>
    <div className="panel"><h2>This month</h2><Stats l={month} /></div>
    <div className="panel"><h2>Yearly report</h2>
      <label>Year</label><select value={y} onChange={e => setY(+e.target.value)}>{years.map(v => <option key={v}>{v}</option>)}</select>
      <div style={{ marginTop: 10 }}><Stats l={sales} /></div>
      <div className="bars">{m.map((x, i) => <div className="bar" key={i} title={`${MONTHS[i]}: ${inr(x.rev)} sales, ${inr(x.pr)} profit`}>
        <i style={{ height: (x.rev / max * 100) + '%' }}><u style={{ height: x.rev ? Math.max(0, x.pr / x.rev * 100) + '%' : 0 }} /></i>{MONTHS[i]}</div>)}</div>
      <p className="legend">Light bar = turnover. Dark part = profit.</p>
      <div className="tw"><table><thead><tr><th>Month</th><th>Bills</th><th>Turnover</th><th>Profit</th></tr></thead><tbody>
        {m.map((x, i) => <tr key={i}><td>{MONTHS[i]}</td><td>{x.n}</td><td>{inr(x.rev)}</td><td>{inr(x.pr)}</td></tr>)}
        <tr><th>Total</th><th>{sales.length}</th><th>{inr(stat(sales).rev)}</th><th>{inr(stat(sales).pr)}</th></tr></tbody></table></div>
      <button className="btn l" style={{ marginTop: 10 }} onClick={() => download(`sales-report-${y}.csv`, csv([['Bill', 'Date', 'Customer', 'Phone', 'Items', 'Payment', 'Discount', 'Total', 'Profit'], ...sales.map(s => [s.no, dt(s).toLocaleString('en-IN'), s.customer, s.phone, s.items.map(i => `${i.name} ${i.size} x${i.qty}`).join('; '), s.mode, s.disc, s.total, s.profit])]))}>Download year report (CSV)</button>
    </div>
    <div className="panel"><h2>Best sellers this month</h2>{top.length ? top.map(([n, q]) => <div key={n} style={{ padding: '4px 0' }}>{n} — {q} sold</div>) : <p className="tag">No sales this month yet.</p>}</div>
    <div className="panel"><h2>Recent bills</h2><div className="tw"><table>
      {sales.length ? <><thead><tr><th>Bill</th><th>Date</th><th>Pay</th><th>Total</th><th>Profit</th></tr></thead><tbody>{sales.slice(0, 15).map(s => <tr key={s._id}><td>{s.no}</td><td>{dt(s).toLocaleDateString('en-IN')}</td><td>{s.mode}</td><td>{inr(s.total)}</td><td>{inr(s.profit)}</td></tr>)}</tbody></>
        : <tbody><tr><td className="empty">No bills saved yet.</td></tr></tbody>}
    </table></div></div>
  </>);
}

/* ================= OWNER: SETTINGS ================= */
function Settings({ set, say, onSaved }) {
  const [f, setF] = useState({ name: set.name || '', wa: set.wa || '', upi: set.upi || '', adr: set.adr || '' });
  const up = k => e => setF({ ...f, [k]: e.target.value });
  const save = async () => { try { await api('/settings', { method: 'PUT', body: f }); onSaved(); say('Settings saved'); } catch (e) { say(e.message); } };
  return (<div className="panel"><h2>Shop settings</h2>
    <label>Shop name</label><input value={f.name} onChange={up('name')} />
    <label>WhatsApp number with country code (e.g. 919876543210)</label><input inputMode="tel" value={f.wa} onChange={up('wa')} />
    <label>UPI ID (e.g. shop@okicici)</label><input value={f.upi} onChange={up('upi')} />
    <label>Shop address (shown on bill)</label><input value={f.adr} onChange={up('adr')} />
    <button className="btn" style={{ marginTop: 12 }} onClick={save}>Save settings</button>
    <p className="tag">The owner PIN is set in the server .env file (ADMIN_PIN).</p>
  </div>);
}

/* ================= OWNER PANEL ================= */
function Owner({ set, say, onSaved }) {
  const [tab, setTab] = useState('bill'); const [ps, setPs] = useState([]);
  const reload = () => api('/products').then(setPs).catch(e => say(e.message));
  useEffect(() => { reload(); }, []);
  const TABS = [['bill', 'Billing'], ['stock', 'Products & stock'], ['rep', 'Sales & profit'], ['set', 'Settings']];
  return (<>
    <div className="chips">{TABS.map(([k, n]) => <button key={k} className={'chip' + (k === tab ? ' on' : '')} onClick={() => setTab(k)}>{n}</button>)}</div>
    {tab === 'bill' && <Billing set={set} say={say} ps={ps} reload={reload} />}
    {tab === 'stock' && <Products say={say} ps={ps} reload={reload} />}
    {tab === 'rep' && <Reports say={say} />}
    {tab === 'set' && <Settings set={set} say={say} onSaved={onSaved} />}
  </>);
}

/* ================= APP ================= */
export default function App() {
  const [admin, setAdmin] = useState(!!token); const [ask, setAsk] = useState(false);
  const [pin, setPin] = useState(''); const [set, setSet] = useState({ name: 'Singapoore Shoe Mart' }); const [toast, setToast] = useState('');
  const say = m => { setToast(m); setTimeout(() => setToast(''), 2600); };
  const loadSet = () => api('/settings').then(s => { setSet(s); document.title = s.name; }).catch(() => {});
  useEffect(() => { loadSet(); }, [admin]);
  const login = async () => {
    try { const r = await api('/login', { method: 'POST', body: { pin } }); token = r.token; localStorage.setItem('t', token); setAdmin(true); setAsk(false); setPin(''); }
    catch (e) { say(e.message); }
  };
  const logout = () => { token = ''; localStorage.removeItem('t'); setAdmin(false); };
  return (<>
    <header><h1>{set.name}</h1><button onClick={() => admin ? logout() : setAsk(true)}>{admin ? 'Customer view' : 'Owner login'}</button></header>
    <main>{admin ? <Owner set={set} say={say} onSaved={loadSet} /> : <Shop set={set} say={say} />}</main>
    {ask && <div className="modal"><div style={{ textAlign: 'center' }}>
      <h2>Owner login</h2>
      <input className="pin" type="password" inputMode="numeric" maxLength={8} placeholder="PIN" value={pin} autoFocus onChange={e => setPin(e.target.value)} onKeyDown={e => e.key === 'Enter' && login()} />
      <div style={{ display: 'flex', gap: 8, justifyContent: 'center', marginTop: 12 }}><button className="btn" onClick={login}>Open</button><button className="btn l" onClick={() => setAsk(false)}>Cancel</button></div>
    </div></div>}
    {toast && <div className="toast" role="status">{toast}</div>}
  </>);
}
